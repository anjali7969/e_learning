// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cart_item_api_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CartItemApiModel _$CartItemApiModelFromJson(Map<String, dynamic> json) =>
    CartItemApiModel(
      courseId: json['_id'] as String,
      name: json['name'] as String,
      image: json['image'] as String,
      description: json['description'] as String,
      quantity: (json['quantity'] as num).toInt(),
      price: (json['price'] as num).toDouble(),
    );

Map<String, dynamic> _$CartItemApiModelToJson(CartItemApiModel instance) =>
    <String, dynamic>{
      '_id': instance.courseId,
      'name': instance.name,
      'image': instance.image,
      'description': instance.description,
      'quantity': instance.quantity,
      'price': instance.price,
    };
