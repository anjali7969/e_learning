// import 'package:e_learning/features/cart/data/model/cart_api_model.dart';
// import 'package:json_annotation/json_annotation.dart';

// part 'get_all_Carts_dto.g.dart';

// @JsonSerializable(explicitToJson: true)
// class GetAllCartDTO {
//   final bool success;
//   final int count;
//   final List<CartApiModel> Carts; // Renamed from `data` to `Carts` for clarity

//   GetAllCartDTO({
//     required this.success,
//     required this.count,
//     required this.Carts,
//   });

//   factory GetAllCartDTO.fromJson(Map<String, dynamic> json) =>
//       _$GetAllCartDTOFromJson(json);

//   Map<String, dynamic> toJson() => _$GetAllCartDTOToJson(this);
// }
