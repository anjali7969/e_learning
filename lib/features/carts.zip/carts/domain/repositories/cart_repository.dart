import 'package:e_learning/features/carts/data/models/add_cart_request.dart';
import 'package:e_learning/features/carts/data/models/remove_cart.dart';
import 'package:e_learning/features/carts/data/models/update_cart_request.dart';
import 'package:e_learning/features/carts/domain/entities/cart_items.dart';

abstract class CartRepository {
  /// ✅ **Fetch the user's cart**
  Future<List<CartItemEntity>> getCart(String userId);

  /// ✅ **Add a course to the cart**
  Future<bool> addToCart(AddToCartDto request);

  /// ✅ **Update the quantity of a cart item**
  Future<bool> updateCart(UpdateCartDto request);

  /// ✅ **Remove an item from the cart**
  Future<bool> removeCartItem(RemoveCartDto request);

  /// ✅ **Clear the entire cart for the user**
  Future<bool> clearCartItem(String userId);
}
