import 'package:e_learning/features/carts/domain/entities/cart_items.dart';

class CartEntity {
  final String id;
  final String userId;
  final List<CartItemEntity> items;
  final num totalAmount;
  final DateTime createdAt;
  final DateTime updatedAt;

  CartEntity({
    required this.id,
    required this.userId,
    required this.items,
    required this.totalAmount,
    required this.createdAt,
    required this.updatedAt,
  });

  /// ✅ **CopyWith Method for Updating Cart Fields**
  CartEntity copyWith({
    String? id,
    String? userId,
    List<CartItemEntity>? items,
    num? totalAmount,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return CartEntity(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      items: items ?? this.items,
      totalAmount: totalAmount ?? this.totalAmount,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  /// ✅ **Convert Entity to JSON**
  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'userId': userId,
      'items': items.map((item) => item.toJson()).toList(),
      'totalAmount': totalAmount,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  /// ✅ **Convert JSON to Entity**
  factory CartEntity.fromJson(Map<String, dynamic> json) {
    return CartEntity(
      id: json['_id']?.toString() ?? '',
      userId: json['userId']?.toString() ?? '',
      items: (json['items'] as List<dynamic>?)
              ?.map((item) => CartItemEntity.fromJson(item))
              .toList() ??
          [],
      totalAmount: (json['totalAmount'] as num?)?.toDouble() ?? 0.0,
      createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse(json['updatedAt'] ?? '') ?? DateTime.now(),
    );
  }
}
