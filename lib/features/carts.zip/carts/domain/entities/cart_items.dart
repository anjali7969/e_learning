class CartItemEntity {
  final String id;
  final String courseId;
  final String name;
  final String image;
  final String description;
  final num price;
  final int quantity;

  CartItemEntity({
    required this.id,
    required this.courseId,
    required this.name,
    required this.image,
    required this.description,
    required this.price,
    required this.quantity,
  });

  /// ✅ **CopyWith Method for Updating Fields**
  CartItemEntity copyWith({
    String? id,
    String? courseId,
    String? name,
    String? image,
    String? description,
    num? price,
    int? quantity,
  }) {
    return CartItemEntity(
      id: id ?? this.id,
      courseId: courseId ?? this.courseId,
      name: name ?? this.name,
      image: image ?? this.image,
      description: description ?? this.description,
      price: price ?? this.price,
      quantity: quantity ?? this.quantity,
    );
  }

  /// ✅ **Convert Entity to JSON (For API Requests)**
  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'courseId': courseId,
      'name': name,
      'image': image,
      'description': description,
      'price': price,
      'quantity': quantity,
    };
  }

  /// ✅ **Convert JSON to Entity (From API Response)**
  factory CartItemEntity.fromJson(Map<String, dynamic> json) {
    return CartItemEntity(
      id: json['_id']?.toString() ?? '',
      courseId: json['courseId']?.toString() ?? '',
      name: json['name'] ?? 'Unknown Course',
      image: json['image'] ?? '',
      description: json['description'] ?? '',
      price: (json['price'] as num?)?.toDouble() ?? 0.0,
      quantity: (json['quantity'] as num?)?.toInt() ?? 1,
    );
  }

  /// ✅ **Convert Model to Entity (From Data Layer)**
  factory CartItemEntity.fromEntity(CartItemEntity entity) {
    return CartItemEntity(
      id: entity.id,
      courseId: entity.courseId,
      name: entity.name,
      image: entity.image,
      description: entity.description,
      price: entity.price,
      quantity: entity.quantity,
    );
  }

  /// ✅ **Convert Entity to Model (For Data Layer Use)**
  CartItemEntity toEntity() {
    return CartItemEntity(
      id: id,
      courseId: courseId,
      name: name,
      image: image,
      description: description,
      price: price,
      quantity: quantity,
    );
  }
}
