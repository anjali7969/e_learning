// class CartEntity {
//   final String courseId;
//   final String name;
//   final double price;
//   final String image;
//   final int quantity;

//   CartEntity({
//     required this.courseId,
//     required this.name,
//     required this.price,
//     required this.image,
//     required this.quantity,
//   });
// }
