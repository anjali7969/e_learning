class RemoveCartDto {
  final String userId;
  final String courseId;

  RemoveCartDto({required this.userId, required this.courseId});

  /// ✅ **Convert DTO to JSON (For API Requests)**
  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'courseId': courseId,
    };
  }

  /// ✅ **Convert JSON to DTO (For API Responses)**
  factory RemoveCartDto.fromJson(Map<String, dynamic> json) {
    return RemoveCartDto(
      userId: json['userId']?.toString() ?? '',
      courseId: json['courseId']?.toString() ?? '',
    );
  }

  /// ✅ **Readable Debugging Output**
  @override
  String toString() => 'RemoveCartDto(userId: $userId, courseId: $courseId)';
}
