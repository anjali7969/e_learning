class UpdateCartDto {
  final String userId;
  final String courseId;
  final int quantity;

  UpdateCartDto({
    required this.userId,
    required this.courseId,
    required this.quantity,
  });

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'courseId': courseId,
      'quantity': quantity,
    };
  }

  factory UpdateCartDto.fromJson(Map<String, dynamic> json) {
    return UpdateCartDto(
      userId: json['userId'],
      courseId: json['courseId'],
      quantity: json['quantity'],
    );
  }
}
