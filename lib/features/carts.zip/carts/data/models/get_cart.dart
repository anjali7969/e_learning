class GetCartDto {
  final String userId;

  GetCartDto({required this.userId});

  /// ✅ **Convert DTO to JSON (For API Requests)**
  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
    };
  }

  /// ✅ **Convert JSON to DTO (For API Responses)**
  factory GetCartDto.fromJson(Map<String, dynamic> json) {
    return GetCartDto(
      userId: json['userId']?.toString() ?? '',
    );
  }

  /// ✅ **Readable Debugging Output**
  @override
  String toString() => 'GetCartDto(userId: $userId)';
}
