import 'package:e_learning/features/carts/domain/entities/cart.dart';
import 'package:e_learning/features/carts/domain/entities/cart_items.dart';

class CartResponseModel {
  final bool success;
  final String message;
  final CartDataModel data;

  CartResponseModel({
    required this.success,
    required this.message,
    required this.data,
  });

  /// ✅ **Convert JSON to Model**
  factory CartResponseModel.fromJson(Map<String, dynamic> json) {
    return CartResponseModel(
      success: json["success"] ?? false,
      message: json["message"] ?? '',
      data: json.containsKey("data")
          ? CartDataModel.fromJson(json["data"])
          : CartDataModel.empty(),
    );
  }

  /// ✅ **Convert Model to JSON**
  Map<String, dynamic> toJson() {
    return {
      "success": success,
      "message": message,
      "data": data.toJson(),
    };
  }
}

class CartDataModel {
  final String cartId;
  final String userId;
  final double totalAmount;
  final List<CartItemEntity> cartItems;
  final DateTime createdAt;
  final DateTime updatedAt;

  CartDataModel({
    required this.cartId,
    required this.userId,
    required this.totalAmount,
    required this.cartItems,
    required this.createdAt,
    required this.updatedAt,
  });

  /// ✅ **Convert JSON to Model**
  factory CartDataModel.fromJson(Map<String, dynamic> json) {
    return CartDataModel(
      cartId: json["cart"]?["_id"]?.toString() ?? '',
      userId: json["cart"]?["userId"]?.toString() ?? '',
      totalAmount: (json["cart"]?["totalAmount"] as num?)?.toDouble() ?? 0.0,
      cartItems: (json["cart"]?["items"] as List<dynamic>?)
              ?.map((item) => CartItemEntity.fromJson(item))
              .toList() ??
          [],
      createdAt: json["cart"]?["createdAt"] != null
          ? DateTime.parse(json["cart"]["createdAt"])
          : DateTime.now(),
      updatedAt: json["cart"]?["updatedAt"] != null
          ? DateTime.parse(json["cart"]["updatedAt"])
          : DateTime.now(),
    );
  }

  /// ✅ **Convert Model to JSON**
  Map<String, dynamic> toJson() {
    return {
      "cartId": cartId,
      "userId": userId,
      "totalAmount": totalAmount,
      "cartItems": cartItems.map((item) => item.toJson()).toList(),
      "createdAt": createdAt.toIso8601String(),
      "updatedAt": updatedAt.toIso8601String(),
    };
  }

  /// ✅ **Convert to Entity**
  CartEntity toEntity() {
    return CartEntity(
      id: cartId,
      userId: userId,
      totalAmount: totalAmount,
      items: cartItems.map((item) => item.toEntity()).toList(),
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }

  /// ✅ **Convert Entity to Model**
  factory CartDataModel.fromEntity(CartEntity entity) {
    return CartDataModel(
      cartId: entity.id,
      userId: entity.userId,
      totalAmount: entity.totalAmount.toDouble(),
      cartItems:
          entity.items.map((item) => CartItemEntity.fromEntity(item)).toList(),
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
    );
  }

  /// ✅ **Empty Cart Data (Default Fallback)**
  factory CartDataModel.empty() {
    return CartDataModel(
      cartId: '',
      userId: '',
      totalAmount: 0.0,
      cartItems: [],
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }
}
