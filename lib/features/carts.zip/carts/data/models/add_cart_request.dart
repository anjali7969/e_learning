class AddToCartDto {
  final String userId;
  final String courseId;
  final int quantity;

  AddToCartDto({
    required this.userId,
    required this.courseId,
    this.quantity = 1,
  });

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'courseId': courseId,
      'quantity': quantity,
    };
  }

  factory AddToCartDto.fromJson(Map<String, dynamic> json) {
    return AddToCartDto(
      userId: json['userId'],
      courseId: json['courseId'],
      quantity: json['quantity'] ?? 1,
    );
  }
}
