import 'package:dio/dio.dart';
import 'package:e_learning/app/constants/api_endpoints.dart';
import 'package:e_learning/features/carts/data/models/add_cart_request.dart';
import 'package:e_learning/features/carts/data/models/cart_request.dart';
import 'package:e_learning/features/carts/data/models/cart_response.dart';
import 'package:e_learning/features/carts/data/models/remove_cart.dart';
import 'package:e_learning/features/carts/data/models/update_cart_request.dart';

abstract class CartRemoteDataSource {
  Future<CartResponseModel> getCart(CartRequestDto request);
  Future<bool> addToCart(AddToCartDto request);
  Future<bool> updateCart(UpdateCartDto request);
  Future<bool> removeCartItem(RemoveCartDto request);
  Future<bool> clearCartItem(String userId);
}

class CartRemoteDataSourceImpl implements CartRemoteDataSource {
  final Dio dio;

  CartRemoteDataSourceImpl({required this.dio});

  @override
  Future<CartResponseModel> getCart(CartRequestDto request) async {
    try {
      final response = await dio.get(ApiEndpoints.getCart,
          queryParameters: request.toJson());
      return CartResponseModel.fromJson(response.data);
    } catch (e) {
      throw Exception("Failed to load cart: $e");
    }
  }

  @override
  Future<bool> addToCart(AddToCartDto request) async {
    try {
      final response =
          await dio.post(ApiEndpoints.addToCart, data: request.toJson());
      return response.data['success'];
    } catch (e) {
      throw Exception("Failed to add to cart: $e");
    }
  }

  @override
  Future<bool> updateCart(UpdateCartDto request) async {
    try {
      final response =
          await dio.put(ApiEndpoints.updateCartItem, data: request.toJson());
      return response.data['success'];
    } catch (e) {
      throw Exception("Failed to update cart: $e");
    }
  }

  @override
  Future<bool> removeCartItem(RemoveCartDto request) async {
    try {
      final response =
          await dio.delete(ApiEndpoints.removeCartItem, data: request.toJson());
      return response.data['success'];
    } catch (e) {
      throw Exception("Failed to remove cart item: $e");
    }
  }

  /// ✅ **Fix for missing `clearCart` method**
  @override
  Future<bool> clearCartItem(String userId) async {
    try {
      final response = await dio.delete(
        "${ApiEndpoints.clearCart}$userId",
      );
      return response.statusCode == 200;
    } catch (e) {
      throw Exception("Failed to clear cart: $e");
    }
  }
}
