import 'package:e_learning/features/carts/data/datasource/cart_remote_datasource.dart';
import 'package:e_learning/features/carts/data/models/add_cart_request.dart';
import 'package:e_learning/features/carts/data/models/remove_cart.dart';
import 'package:e_learning/features/carts/data/models/update_cart_request.dart';
import 'package:e_learning/features/carts/domain/entities/cart_items.dart';
import 'package:e_learning/features/carts/domain/repositories/cart_repository.dart';

class CartRepositoryImpl implements CartRepository {
  final CartRemoteDataSource remoteDataSource;

  CartRepositoryImpl({required this.remoteDataSource});

  /// ✅ **Fetch Cart Data**
  @override
  Future<List<CartItemEntity>> getCart(String userId) async {
    final cartResponse = await remoteDataSource.getCart(userId);
    return cartResponse.items
        .map((item) => CartItemEntity.fromModel(item))
        .toList();
  }

  /// ✅ **Add a Course to Cart**
  @override
  Future<bool> addToCart(AddToCartDto addCartRequest) async {
    return await remoteDataSource.addToCart(addCartRequest);
  }

  /// ✅ **Update Cart Quantity**
  @override
  Future<bool> updateCart(UpdateCartDto updateRequest) async {
    return await remoteDataSource.updateCart(updateRequest);
  }

  /// ✅ **Remove an Item from the Cart**
  @override
  Future<bool> removeCartItem(RemoveCartDto removeRequest) async {
    return await remoteDataSource.removeCartItem(removeRequest);
  }

  /// ✅ **Clear the Entire Cart**
  @override
  Future<bool> clearCartItem(String userId) async {
    return await remoteDataSource.clearCartItem(userId);
  }
}
